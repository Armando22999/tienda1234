 <!-- main-footer -->
<footer class="main-footer">

<strong>Copyright &copy; <a href="#"></a>.</strong> Todos los derechos reservados.

</footer>
<!-- main-footer -->